export interface Member {
  id: string;
  name: string;
  joinedDate: string;
  phone: string;
}

export interface SavingsEntry {
  id: string;
  memberId: string;
  amount: number;
  date: string;
}

export interface Loan {
  id: string;
  memberId: string;
  amount: number;
  interestRate: number; // monthly interest rate in %
  purpose: string;
  status: 'active' | 'paid';
  startDate: string;
}

export interface SHGData {
  members: Member[];
  savings: SavingsEntry[];
  loans: Loan[];
}
