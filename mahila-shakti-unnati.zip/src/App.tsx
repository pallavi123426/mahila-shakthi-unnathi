import React, { useState, useEffect } from 'react';
import { 
  Users, 
  PiggyBank, 
  HandCoins, 
  LayoutDashboard, 
  Plus, 
  Search, 
  Share2, 
  Sparkles,
  TrendingUp,
  Wallet,
  CreditCard,
  MessageCircle,
  Clock,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Download,
  Printer,
  FileSpreadsheet
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import ReactMarkdown from 'react-markdown';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

import { SHGData, Member, SavingsEntry, Loan } from './types/shg';
import { getSHGData, saveSHGData, calculateMemberSavings, calculateMemberLoanBalance } from './lib/storage';

export default function App() {
  const [data, setData] = useState<SHGData>(getSHGData());
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isAIAnalysing, setIsAIAnalysing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);

  // Auto-save data whenever it changes
  useEffect(() => {
    saveSHGData(data);
  }, [data]);

  // Totals
  const totalSavings = data.savings.reduce((sum, s) => sum + s.amount, 0);
  const totalActiveLoans = data.loans.filter(l => l.status === 'active').reduce((sum, l) => sum + l.amount, 0);
  const totalCapital = totalSavings - totalActiveLoans;

  // Add Member
  const addMember = (name: string, phone: string) => {
    const newMember: Member = {
      id: Date.now().toString(),
      name,
      phone,
      joinedDate: new Date().toISOString().split('T')[0]
    };
    setData(prev => ({ ...prev, members: [...prev.members, newMember] }));
    toast.success(`${name} added to the group!`);
  };

  // Add Savings
  const addSavings = (memberId: string, amount: number) => {
    const newSavings: SavingsEntry = {
      id: Date.now().toString(),
      memberId,
      amount,
      date: new Date().toISOString().split('T')[0]
    };
    setData(prev => ({ ...prev, savings: [...prev.savings, newSavings] }));
    const memberName = data.members.find(m => m.id === memberId)?.name;
    toast.success(`₹${amount} savings recorded for ${memberName}`);
  };

  // Record Loan
  const recordLoan = (memberId: string, amount: number, purpose: string, rate: number) => {
    // Check if member already has an active loan
    const hasActiveLoan = data.loans.some(l => l.memberId === memberId && l.status === 'active');
    if (hasActiveLoan) {
      toast.error('This member already has an unpaid loan.');
      return;
    }

    const newLoan: Loan = {
      id: Date.now().toString(),
      memberId,
      amount,
      interestRate: rate,
      purpose,
      status: 'active',
      startDate: new Date().toISOString().split('T')[0]
    };
    setData(prev => ({ ...prev, loans: [...prev.loans, newLoan] }));
    const memberName = data.members.find(m => m.id === memberId)?.name;
    toast.success(`₹${amount} loan granted to ${memberName}`);
  };

  // Repay Loan
  const repayLoan = (loanId: string) => {
    setData(prev => ({
      ...prev,
      loans: prev.loans.map(l => l.id === loanId ? ({ ...l, status: 'paid' }) : l)
    }));
    toast.success('Loan repayment recorded successfully.');
  };

  // AI Analysis
  const getAIInsights = async () => {
    setIsAIAnalysing(true);
    setAiAnalysis(null);
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ groupData: data })
      });
      const result = await res.json();
      setAiAnalysis(result.analysis);
    } catch (err) {
      toast.error('Failed to get AI insights.');
    } finally {
      setIsAIAnalysing(false);
    }
  };

  // WhatsApp Export
  const shareOnWhatsApp = () => {
    const text = `SHG Financial Summary: ${new Date().toLocaleDateString()}\n\nTotal Group Savings: ₹${totalSavings}\nActive Loans: ₹${totalActiveLoans}\nAvailable Capital: ₹${totalCapital}\n\nGroup Members: ${data.members.length}\n\nRecorded by Mahila-Shakti Unnati`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const exportCSV = () => {
    let csv = "Member Name,Phone,Joined Date,Total Savings,Active Loan Balance\n";
    data.members.forEach(member => {
      const savings = calculateMemberSavings(member.id, data.savings);
      const loan = calculateMemberLoanBalance(member.id, data.loans);
      csv += `"${member.name}","${member.phone}","${member.joinedDate}",${savings},${loan}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `SHG_Data_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("CSV Exported successfully");
  };

  const printSummary = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#1A1A1A] font-sans selection:bg-orange-100 p-4 md:p-8">
      <Toaster />
      
      {/* Header Section */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6 max-w-6xl mx-auto">
        <div className="no-print">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#2D5A27] mb-2">Empowering Women's SHGs</p>
          <h1 className="text-5xl md:text-7xl font-black leading-[0.9] tracking-tighter uppercase">
            Mahila-Shakti<br/>
            <span className="text-[#2D5A27]">Unnati</span>
          </h1>
        </div>
        
        {/* Print Title (Only visible during print) */}
        <div className="print-only hidden">
          <p className="text-sm font-black uppercase tracking-widest text-[#2D5A27]">Mahila-Shakti Unnati</p>
          <h1 className="text-4xl font-black uppercase">Financial Summary Report</h1>
          <p className="text-sm font-mono opacity-60">Generated: {new Date().toLocaleString()}</p>
        </div>

        <div className="text-left md:text-right no-print">
          <p className="text-sm font-medium opacity-60">Digital Accountant • Unit 04</p>
          <p className="text-2xl font-bold font-mono uppercase">{new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
          <div className="flex flex-wrap gap-2 mt-4 md:justify-end">
            <Button variant="outline" size="sm" onClick={shareOnWhatsApp} className="rounded-xl border-2 border-[#1A1A1A] font-bold uppercase tracking-wider text-[10px]">
              <Share2 size={14} className="mr-2" /> WhatsApp
            </Button>
            <Button variant="outline" size="sm" onClick={exportCSV} className="rounded-xl border-2 border-[#1A1A1A] font-bold uppercase tracking-wider text-[10px]">
              <FileSpreadsheet size={14} className="mr-2" /> CSV
            </Button>
            <Button variant="outline" size="sm" onClick={printSummary} className="rounded-xl border-2 border-[#1A1A1A] font-bold uppercase tracking-wider text-[10px]">
              <Printer size={14} className="mr-2" /> Print PDF
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto space-y-12">
        {/* Top Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="border-t-[6px] border-[#2D5A27] pt-4">
            <p className="text-[10px] uppercase font-black tracking-widest mb-1 opacity-60">Total Group Savings</p>
            <p className="text-5xl font-black text-[#2D5A27] font-mono">₹{totalSavings.toLocaleString('en-IN')}</p>
          </div>
          <div className="border-t-[6px] border-[#1A1A1A] pt-4">
            <p className="text-[10px] uppercase font-black tracking-widest mb-1 opacity-60">Active Loans</p>
            <p className="text-5xl font-black italic font-mono">₹{totalActiveLoans.toLocaleString('en-IN')}</p>
          </div>
          <div className="border-t-[6px] border-[#E29578] pt-4">
            <p className="text-[10px] uppercase font-black tracking-widest mb-1 opacity-60">Available Capital</p>
            <p className="text-5xl font-black text-[#E29578] font-mono">₹{totalCapital.toLocaleString('en-IN')}</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <div className="flex overflow-x-auto pb-2 scrollbar-hide border-b border-gray-200">
            <TabsList className="h-14 w-full justify-start p-0 bg-transparent gap-8">
              {['dashboard', 'members', 'savings', 'loans'].map((tab) => (
                <TabsTrigger 
                  key={tab}
                  value={tab} 
                  className="rounded-none border-b-4 border-transparent data-[state=active]:border-[#1A1A1A] data-[state=active]:bg-transparent px-0 text-xs font-black uppercase tracking-widest transition-all h-full"
                >
                  {tab}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              {/* Dashboard Content */}
              <TabsContent value="dashboard" className="space-y-8 outline-none">
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                  <div className="lg:col-span-3 space-y-8">
                    <Card className="rounded-2xl border-2 border-gray-100 shadow-none overflow-hidden">
                      <CardHeader className="bg-gray-50/50 border-b border-gray-100">
                        <CardTitle className="text-xs font-black uppercase tracking-[0.2em] flex items-center gap-2">
                          <TrendingUp size={16} className="text-emerald-600" />
                          Savings Distribution
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="h-[340px] pt-8">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={data.members.map(m => ({ 
                            name: m.name, 
                            savings: calculateMemberSavings(m.id, data.savings) 
                          }))}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEE" />
                            <XAxis dataKey="name" fontSize={10} fontWeight={700} tickLine={false} axisLine={false} />
                            <YAxis fontSize={10} fontWeight={700} tickLine={false} axisLine={false} tickFormatter={(val) => `₹${val}`} />
                            <Tooltip 
                              contentStyle={{ borderRadius: '4px', border: '2px solid #1A1A1A', boxShadow: '4px 4px 0px rgba(0,0,0,0.1)' }} 
                              labelStyle={{ fontWeight: 900, textTransform: 'uppercase', fontSize: '10px' }}
                              formatter={(val) => [`₹${val}`, 'Savings']}
                            />
                            <Bar dataKey="savings" fill="#2D5A27" radius={[2, 2, 0, 0]} barSize={40} />
                          </BarChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>

                    <div className="bg-[#E29578] p-8 rounded-3xl text-white">
                      <h3 className="text-xs uppercase font-black tracking-widest mb-6 opacity-80">Quick Actions</h3>
                      <div className="flex flex-col sm:flex-row gap-4">
                        <AddMemberDialog onAdd={addMember} className="flex-1 bg-white/20 hover:bg-white/30 border border-white/40 text-white rounded-xl h-14" />
                        <Button onClick={() => setActiveTab('savings')} className="flex-1 bg-white/20 hover:bg-white/30 border border-white/40 text-white rounded-xl h-14 font-black uppercase tracking-widest text-xs">
                          Log Saving
                        </Button>
                        <Button onClick={() => setActiveTab('loans')} className="flex-1 bg-white/20 hover:bg-white/30 border border-white/40 text-white rounded-xl h-14 font-black uppercase tracking-widest text-xs">
                          Issue Loan
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="lg:col-span-2 flex flex-col gap-8">
                    <Card className="rounded-3xl border-none shadow-xl bg-[#2D5A27] text-white flex-grow overflow-hidden">
                      <div className="p-8 flex flex-col h-full justify-between gap-8">
                        <div>
                          <h3 className="text-[10px] uppercase font-black tracking-[0.3em] mb-8 opacity-60">Digital Accountant AI</h3>
                          <p className="text-4xl font-black leading-tight tracking-tighter uppercase mb-4">
                            Financial Insights
                          </p>
                          {aiAnalysis ? (
                            <div className="bg-white/10 p-5 rounded-2xl border border-white/10 prose prose-sm prose-invert max-w-none overflow-y-auto max-h-[280px] scrollbar-hide text-sm leading-relaxed font-medium">
                              <ReactMarkdown>{aiAnalysis}</ReactMarkdown>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center justify-center py-12 text-center opacity-60 gap-4">
                              <Sparkles size={48} className="animate-pulse" />
                              <p className="max-w-[200px] text-xs font-bold uppercase tracking-widest">Ready to analyze your SHG data</p>
                            </div>
                          )}
                        </div>
                        <Button 
                          onClick={getAIInsights} 
                          className="w-full bg-[#FDFBF7] text-[#2D5A27] hover:bg-white py-8 rounded-2xl font-black uppercase tracking-widest text-sm shadow-2xl transition-all active:scale-95"
                          disabled={isAIAnalysing || data.members.length === 0}
                        >
                          {isAIAnalysing ? 'Analysing...' : aiAnalysis ? 'Refresh Report' : 'Get AI Diagnosis'}
                        </Button>
                      </div>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              {/* Members Content */}
              <TabsContent value="members" className="space-y-8 outline-none">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="relative w-full max-w-md">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                    <Input placeholder="Search members..." className="pl-12 h-14 rounded-2xl border-2 border-gray-100 bg-white focus:border-[#1A1A1A] transition-all" />
                  </div>
                  <AddMemberDialog onAdd={addMember} className="bg-[#1A1A1A] h-14 px-8 rounded-2xl text-white hover:bg-black" />
                </div>

                <div className="bg-white border-2 border-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent border-b-2 border-gray-100">
                        <TableHead className="py-6 px-8 text-[10px] font-black uppercase tracking-widest">Member Identity</TableHead>
                        <TableHead className="text-[10px] font-black uppercase tracking-widest">Contact</TableHead>
                        <TableHead className="text-[10px] font-black uppercase tracking-widest">Joined</TableHead>
                        <TableHead className="text-right text-[10px] font-black uppercase tracking-widest">Total Savings</TableHead>
                        <TableHead className="text-right text-[10px] font-black uppercase tracking-widest">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.members.map((member) => (
                        <TableRow key={member.id} className="group hover:bg-gray-50/50 border-b border-gray-50 last:border-0">
                          <TableCell className="py-6 px-8 font-black text-lg">{member.name}</TableCell>
                          <TableCell className="font-mono text-sm opacity-60">{member.phone}</TableCell>
                          <TableCell className="text-sm font-bold opacity-60 italic">{member.joinedDate}</TableCell>
                          <TableCell className="text-right font-black text-xl text-[#2D5A27] font-mono">
                            ₹{calculateMemberSavings(member.id, data.savings)}
                          </TableCell>
                          <TableCell className="text-right px-8">
                            {calculateMemberLoanBalance(member.id, data.loans) > 0 ? (
                              <Badge className="bg-orange-100 text-orange-800 rounded-lg border-0 px-3 py-1 font-black text-[10px] uppercase">
                                Active Loan: ₹{calculateMemberLoanBalance(member.id, data.loans)}
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="text-[10px] font-black uppercase border-2 text-gray-400">Debt Free</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              {/* Savings Content */}
              <TabsContent value="savings" className="space-y-8 outline-none">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                  <Card className="lg:col-span-1 rounded-3xl border-none bg-[#1A1A1A] text-white p-2">
                    <div className="p-6 space-y-6">
                      <div>
                        <h3 className="text-xs font-black uppercase tracking-widest mb-1 opacity-60">Log Entry</h3>
                        <p className="text-2xl font-black uppercase tracking-tighter">Weekly Saving</p>
                      </div>
                      <SavingsForm members={data.members} onAdd={addSavings} />
                    </div>
                  </Card>

                  <div className="lg:col-span-3 bg-white border-2 border-gray-100 rounded-3xl overflow-hidden shadow-sm">
                    <div className="p-6 border-b-2 border-gray-100 flex justify-between items-center bg-gray-50/30">
                      <h3 className="text-xs font-black uppercase tracking-widest">Entry History</h3>
                      <Badge className="bg-[#2D5A27] font-black uppercase text-[10px]">{data.savings.length} RECORDS</Badge>
                    </div>
                    <ScrollArea className="h-[500px]">
                      <Table>
                        <TableHeader>
                          <TableRow className="hover:bg-transparent border-b border-gray-100">
                            <TableHead className="py-4 px-8 text-[10px] font-black uppercase tracking-widest">Date</TableHead>
                            <TableHead className="text-[10px] font-black uppercase tracking-widest">Contributor</TableHead>
                            <TableHead className="text-right px-8 text-[10px] font-black uppercase tracking-widest">Amount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {[...data.savings].reverse().map((s) => (
                            <TableRow key={s.id} className="hover:bg-gray-50/50">
                              <TableCell className="px-8 font-mono text-xs font-bold opacity-60">{s.date}</TableCell>
                              <TableCell className="font-black">{data.members.find(m => m.id === s.memberId)?.name}</TableCell>
                              <TableCell className="text-right px-8 font-black text-lg text-[#2D5A27] font-mono">+₹{s.amount}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </ScrollArea>
                  </div>
                </div>
              </TabsContent>

              {/* Loans Content */}
              <TabsContent value="loans" className="space-y-8 outline-none">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                  <Card className="lg:col-span-1 rounded-3xl border-none bg-[#E29578] text-white p-2">
                    <div className="p-6 space-y-6">
                      <div>
                        <h3 className="text-xs font-black uppercase tracking-widest mb-1 opacity-60">Action</h3>
                        <p className="text-2xl font-black uppercase tracking-tighter">Grant Credit</p>
                      </div>
                      <LoanForm members={data.members} onAdd={recordLoan} />
                    </div>
                  </Card>

                  <div className="lg:col-span-3 space-y-6">
                    <div className="bg-white border-2 border-gray-100 rounded-3xl overflow-hidden shadow-sm">
                      <div className="p-6 border-b-2 border-gray-100 flex justify-between items-center bg-gray-50/30">
                        <h3 className="text-xs font-black uppercase tracking-widest">Active Credits</h3>
                        <Badge className="bg-orange-600 font-black uppercase text-[10px]">Ongoing</Badge>
                      </div>
                      <Table>
                        <TableHeader>
                          <TableRow className="hover:bg-transparent border-b border-gray-100">
                            <TableHead className="py-4 px-8 text-[10px] font-black uppercase tracking-widest">Borrower</TableHead>
                            <TableHead className="text-[10px] font-black uppercase tracking-widest">Purpose</TableHead>
                            <TableHead className="text-right px-8 text-[10px] font-black uppercase tracking-widest">Principal</TableHead>
                            <TableHead className="text-right px-8 text-[10px] font-black uppercase tracking-widest">Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {data.loans.filter(l => l.status === 'active').map((loan) => (
                            <TableRow key={loan.id} className="hover:bg-orange-50/20">
                              <TableCell className="px-8 py-5">
                                <div className="font-black text-lg">{data.members.find(m => m.id === loan.memberId)?.name}</div>
                                <div className="text-[10px] font-black uppercase tracking-widest text-[#E29578] mt-1">{loan.interestRate}% Monthly Int.</div>
                              </TableCell>
                              <TableCell className="font-bold opacity-70 italic text-sm">{loan.purpose}</TableCell>
                              <TableCell className="text-right px-8 font-black text-xl font-mono italic">₹{loan.amount}</TableCell>
                              <TableCell className="text-right px-8 flex items-center justify-end gap-2">
                                <LoanScheduleDialog loan={loan} memberName={data.members.find(m => m.id === loan.memberId)?.name || ''} />
                                <Button size="sm" onClick={() => repayLoan(loan.id)} className="bg-[#1A1A1A] hover:bg-black rounded-lg text-[10px] font-black uppercase tracking-widest px-4 h-9">
                                  Mark Paid
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                          {data.loans.filter(l => l.status === 'active').length === 0 && (
                            <TableRow>
                              <TableCell colSpan={4} className="h-40 text-center text-xs font-black uppercase tracking-widest opacity-30">
                                No credit issued currently
                              </TableCell>
                            </TableRow>
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </motion.div>
          </AnimatePresence>
        </Tabs>

        {/* Footer Section */}
        <footer className="mt-16 flex flex-col sm:flex-row justify-between items-center border-t-2 border-gray-100 pt-8 gap-4">
          <div className="flex flex-wrap justify-center gap-8 text-[10px] font-black uppercase tracking-widest text-gray-300">
            <span>Ver 1.0.8-Alpha</span>
            <span>Room DB Secured</span>
            <span>SHG Financial Literacy</span>
          </div>
          <div className="flex gap-2 items-center">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">System Live • Secured</span>
          </div>
        </footer>

        {/* Hidden Print Report Container */}
        <div className="print-only hidden print:block mt-12 space-y-12">
          <div className="grid grid-cols-2 gap-8 border-b-2 border-black pb-8">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40">Group Capitalization</p>
              <div className="space-y-4 mt-4">
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="font-bold uppercase text-xs">Total Savings</span>
                  <span className="font-mono font-black">₹{totalSavings.toLocaleString()}</span>
                </div>
                <div className="flex justify-between border-b border-gray-100 pb-2">
                  <span className="font-bold uppercase text-xs">Total Active Loans</span>
                  <span className="font-mono font-black">₹{totalActiveLoans.toLocaleString()}</span>
                </div>
                <div className="flex justify-between pt-2">
                  <span className="font-black uppercase text-sm">Available Cash</span>
                  <span className="font-mono font-black text-xl">₹{totalCapital.toLocaleString()}</span>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-2xl">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 mb-4">Member Standings</p>
              <div className="space-y-2">
                <p className="text-xs font-bold uppercase">Total Members: {data.members.length}</p>
                <p className="text-xs font-bold uppercase">Active Borrowers: {data.loans.filter(l => l.status === 'active').length}</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-black uppercase tracking-widest border-b-2 border-black pb-2">Detailed Member Ledger</h3>
            <Table>
              <TableHeader>
                <TableRow className="border-b border-black">
                  <TableHead className="text-[10px] font-black uppercase text-black">Member Name</TableHead>
                  <TableHead className="text-[10px] font-black uppercase text-black">Savings</TableHead>
                  <TableHead className="text-[10px] font-black uppercase text-black">Loan Balance</TableHead>
                  <TableHead className="text-[10px] font-black uppercase text-black">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.members.map(m => (
                  <TableRow key={m.id} className="border-b border-gray-100">
                    <TableCell className="font-black py-4 uppercase text-sm">{m.name}</TableCell>
                    <TableCell className="font-mono font-bold">₹{calculateMemberSavings(m.id, data.savings)}</TableCell>
                    <TableCell className="font-mono font-bold">₹{calculateMemberLoanBalance(m.id, data.loans)}</TableCell>
                    <TableCell className="text-[9px] font-black uppercase">
                      {calculateMemberLoanBalance(m.id, data.loans) > 0 ? "Active Debt" : "Clear"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="pt-24 text-center">
            <div className="flex justify-between gap-12">
              <div className="flex-1 border-t border-black pt-2">
                <p className="text-[10px] font-black uppercase">SHG Secretary Signature</p>
              </div>
              <div className="flex-1 border-t border-black pt-2">
                <p className="text-[10px] font-black uppercase">Group President Signature</p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

// Updated Sub-components with theme styling
function AddMemberDialog({ onAdd, className }: { onAdd: (name: string, phone: string) => void, className?: string }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [open, setOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && phone) {
      onAdd(name, phone);
      setName('');
      setPhone('');
      setOpen(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger render={<Button className={cn("gap-2 font-black uppercase tracking-widest text-xs", className)} />}>
        <Plus size={18} /> New Member
      </DialogTrigger>
      <DialogContent className="rounded-3xl border-4 border-[#1A1A1A] p-0 overflow-hidden sm:max-w-md">
        <div className="bg-[#1A1A1A] p-8 text-white">
          <DialogTitle className="text-3xl font-black uppercase tracking-tighter">Registration</DialogTitle>
          <DialogDescription className="text-white/60 font-bold uppercase text-[10px] tracking-widest mt-2">
            Enter member credentials for the SHG Ledger
          </DialogDescription>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6 bg-white">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-[10px] font-black uppercase tracking-widest opacity-60">Full Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. RADHA DEVI" required className="h-14 rounded-xl border-2 border-gray-100 bg-gray-50 focus:bg-white focus:border-[#1A1A1A] transition-all font-bold uppercase" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone" className="text-[10px] font-black uppercase tracking-widest opacity-60">Contact Number</Label>
            <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="98XXXXXXXX" required className="h-14 rounded-xl border-2 border-gray-100 bg-gray-50 focus:bg-white focus:border-[#1A1A1A] transition-all font-mono" />
          </div>
          <Button type="submit" className="w-full h-16 bg-[#1A1A1A] text-white rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-black">
            Confirm Membership
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function LoanScheduleDialog({ loan, memberName }: { loan: Loan, memberName: string }) {
  const schedule = Array.from({ length: 12 }, (_, i) => {
    const date = new Date(loan.startDate);
    date.setMonth(date.getMonth() + i + 1);
    const principal = loan.amount / 12;
    const interest = (loan.amount * (loan.interestRate / 100));
    return {
      month: i + 1,
      date: date.toISOString().split('T')[0],
      principal,
      interest,
      total: principal + interest
    };
  });

  return (
    <Dialog>
      <DialogTrigger render={<Button variant="outline" size="sm" className="h-9 px-3 rounded-lg border-2 border-gray-100 hover:border-[#1A1A1A] group transition-all" />}>
        <Calendar size={14} className="mr-2 text-gray-400 group-hover:text-[#1A1A1A]" />
        <span className="text-[10px] font-black uppercase tracking-widest text-[#1A1A1A]">Schedule</span>
      </DialogTrigger>
      <DialogContent className="rounded-3xl border-4 border-[#1A1A1A] p-0 overflow-hidden sm:max-w-lg">
        <div className="bg-[#1A1A1A] p-8 text-white">
          <DialogTitle className="text-3xl font-black uppercase tracking-tighter">Repayment Schedule</DialogTitle>
          <DialogDescription className="text-white/60 font-bold uppercase text-[10px] tracking-widest mt-2">
            12-Month Forecast for {memberName}
          </DialogDescription>
        </div>
        <div className="p-0 bg-white">
          <ScrollArea className="h-[400px]">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-b-2 border-gray-100 bg-gray-50/50">
                  <TableHead className="py-4 px-8 text-[10px] font-black uppercase tracking-widest">Month</TableHead>
                  <TableHead className="text-[10px] font-black uppercase tracking-widest">Due Date</TableHead>
                  <TableHead className="text-right px-8 text-[10px] font-black uppercase tracking-widest">Installment</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {schedule.map((item) => (
                  <TableRow key={item.month} className="hover:bg-gray-50/50 border-b border-gray-50 last:border-0">
                    <TableCell className="px-8 py-4 font-black">Month {item.month}</TableCell>
                    <TableCell className="font-mono text-xs opacity-60">{item.date}</TableCell>
                    <TableCell className="text-right px-8">
                      <div className="font-black text-[#E29578] font-mono">₹{item.total.toFixed(2)}</div>
                      <div className="text-[9px] font-bold opacity-40 uppercase tracking-tighter">
                        P: ₹{item.principal.toFixed(0)} + I: ₹{item.interest.toFixed(0)}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function SavingsForm({ members, onAdd }: { members: Member[], onAdd: (id: string, amount: number) => void }) {
  const [selectedMember, setSelectedMember] = useState('');
  const [amount, setAmount] = useState('200');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedMember && amount) {
      onAdd(selectedMember, parseFloat(amount));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 pb-4">
      <div className="space-y-2">
        <Label className="text-[10px] font-black uppercase tracking-widest text-white/50">Select contributor</Label>
        <Select value={selectedMember} onValueChange={setSelectedMember}>
          <SelectTrigger className="h-14 rounded-xl bg-white/10 border-white/20 text-white font-bold uppercase text-xs">
            <SelectValue placeholder="Choose name" />
          </SelectTrigger>
          <SelectContent className="rounded-xl border-2 border-[#1A1A1A]">
            {members.map(m => (
              <SelectItem key={m.id} value={m.id} className="font-bold uppercase py-3">{m.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label className="text-[10px] font-black uppercase tracking-widest text-white/50">Weekly amount (₹)</Label>
        <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="h-14 rounded-xl bg-white/10 border-white/20 text-white font-black text-xl italic font-mono" required />
      </div>
      <Button type="submit" className="w-full h-14 bg-white text-[#1A1A1A] hover:bg-gray-100 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg" disabled={!selectedMember}>
        Update Ledger
      </Button>
    </form>
  );
}

function LoanForm({ members, onAdd }: { members: Member[], onAdd: (id: string, amount: number, purpose: string, rate: number) => void }) {
  const [selectedMember, setSelectedMember] = useState('');
  const [amount, setAmount] = useState('');
  const [purpose, setPurpose] = useState('');
  const [rate, setRate] = useState('2');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedMember && amount && purpose) {
      onAdd(selectedMember, parseFloat(amount), purpose, parseFloat(rate));
      setAmount('');
      setPurpose('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 pb-4">
      <div className="space-y-2">
        <Label className="text-[10px] font-black uppercase tracking-widest text-white/50">Borrower</Label>
        <Select value={selectedMember} onValueChange={setSelectedMember}>
          <SelectTrigger className="h-12 rounded-xl bg-white/10 border-white/20 text-white font-bold uppercase text-[10px]">
            <SelectValue placeholder="Select name" />
          </SelectTrigger>
          <SelectContent className="rounded-xl border-2 border-[#E29578]">
            {members.map(m => (
              <SelectItem key={m.id} value={m.id} className="font-bold uppercase py-2 text-xs">{m.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1">
        <Label className="text-[10px] font-black uppercase tracking-widest text-white/50">Principal (₹)</Label>
        <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="h-12 rounded-xl bg-white/10 border-white/20 text-white font-black text-lg italic font-mono" required />
      </div>
      <div className="space-y-1">
        <Label className="text-[10px] font-black uppercase tracking-widest text-white/50">Loan Basis</Label>
        <Input value={purpose} onChange={(e) => setPurpose(e.target.value)} placeholder="PURPOSE" className="h-12 rounded-xl bg-white/10 border-white/20 text-white font-bold uppercase text-[10px]" required />
      </div>
      <div className="space-y-1">
        <Label className="text-[10px] font-black uppercase tracking-widest text-white/50">Interest (%)</Label>
        <Input type="number" value={rate} onChange={(e) => setRate(e.target.value)} className="h-12 rounded-xl bg-white/10 border-white/20 text-white font-black text-lg font-mono" required />
      </div>
      <Button type="submit" className="w-full h-12 bg-white text-[#E29578] hover:bg-gray-100 rounded-xl font-black uppercase tracking-widest text-[10px] shadow-lg mt-4" disabled={!selectedMember}>
        Issue Credit
      </Button>
    </form>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
