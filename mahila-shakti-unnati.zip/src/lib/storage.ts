import { SHGData, Member, SavingsEntry, Loan } from '../types/shg';

const STORAGE_KEY = 'mahila_shakti_unnati_data';

export const initialData: SHGData = {
  members: [
    { id: '1', name: 'Savitri Devi', joinedDate: '2024-01-01', phone: '9876543210' },
    { id: '2', name: 'Lakshmi Bai', joinedDate: '2024-01-15', phone: '9876543211' }
  ],
  savings: [],
  loans: []
};

export function getSHGData(): SHGData {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : initialData;
}

export function saveSHGData(data: SHGData) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

export function calculateMemberSavings(memberId: string, savings: SavingsEntry[]): number {
  return savings
    .filter(s => s.memberId === memberId)
    .reduce((sum, s) => sum + s.amount, 0);
}

export function calculateMemberLoanBalance(memberId: string, loans: Loan[]): number {
  return loans
    .filter(l => l.memberId === memberId && l.status === 'active')
    .reduce((sum, l) => sum + l.amount, 0);
}
