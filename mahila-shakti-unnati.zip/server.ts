import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Gemini API setup
  const genAI = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || "",
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // AI Insights API
  app.post("/api/ai/analyze", async (req, res) => {
    try {
      const { groupData } = req.body;
      
      const response = await genAI.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `You are a professional financial advisor for rural Women's Self-Help Groups (SHGs). 
        Analyze the following group data and provide:
        1. A brief summary of the group's financial health.
        2. Suggestions for improving savings or managing loans.
        3. A word of encouragement in a supportive, empowering tone.
        
        Data: ${JSON.stringify(groupData)}
        
        Keep the response concise and friendly. Format as Markdown.`,
      });

      res.json({ analysis: response.text });
    } catch (error) {
      console.error("AI Analysis Error:", error);
      res.status(500).json({ error: "Failed to generate AI insights." });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
